using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoardComp : MonoBehaviour
{
    [SerializeField] GameObject pegPrefab;
    Peg[,] pegs =new Peg[7,7];
    Peg c_Peg;

    Vector3 pegPosition = new Vector3(-0.45f,0f,-0.45f);

    Vector2 mousePos;
    Vector2 firstPegPos;
    Vector2 secondPegPos;
 
  
    void Start(){
        createTable();
    }

    public void createTable(){
        for(int i=0;i<7;i++){
            for(int j=0;j<7;j++){
                if(i!=3 || j!=2){
                    if(j>1 && j<5 || i>1 && i<5){
                        createPeg(i,j);
                    }
                }
            }
        }
        createPeg(1,1);
        createPeg(1,5);
        createPeg(5,1);
        createPeg(5,5);
    }

    private void createPeg(int row, int column){
        GameObject game_object = Instantiate(pegPrefab) as GameObject;
        Peg peg = game_object.GetComponent<Peg>();
        pegs[row,column] = peg;
        movePeg(peg,row,column);
    }

    private void movePeg(Peg peg, int row, int column){
        peg.transform.position = (Vector3.forward * row) + (Vector3.right * column);
    }

    private void playPeg(int x1, int y1, int x2, int y2){
        firstPegPos = new Vector2(x1, y1);
        secondPegPos = new Vector2(x2, y2);
        c_Peg = pegs[x1,y1];
        if(x2 < 0 || x2 > 6 || y2 < 0 || y2 > 6){
            if(c_Peg != null){
                movePeg(c_Peg, x1, y1);
            }
            firstPegPos = Vector2.zero;
            c_Peg = null;
            return;
        }
        
        if(c_Peg != null){
            if(secondPegPos == firstPegPos){
                movePeg(c_Peg, x1, y1);
                firstPegPos = Vector2.zero;
                c_Peg = null;
                return;
            }
            if(is_move_valid(x1,y1,x2,y2)){
                if(x1 == x2){
                    Destroy(pegs[x1, (y1+y2)/2].gameObject);
                    pegs[x1,(y1+y2)/2] = null;
                }
                else{
                    Destroy(pegs[(x1+x2)/2, y1].gameObject);
                    pegs[(x1+x2)/2, y1] = null;
                }
                pegs[x2,y2] = c_Peg;
                pegs[x1,y1] = null;
                movePeg(c_Peg, x2, y2);
                c_Peg = null;
                firstPegPos = Vector2.zero;
            }
        }
    }

    private void Update(){
        pegsPos();

        int x = (int) mousePos.x;
        int y = (int) mousePos.y;

        if(c_Peg != null){
            if(Input.GetMouseButtonDown(0)){
                playPeg((int) firstPegPos.x, (int) firstPegPos.y, x, y);
            }
        }
        else{
            if(Input.GetMouseButtonDown(0)){
                selectPeg(x, y);
                if(c_Peg != null){
                    upraisePeg(c_Peg);
                }
            }
        }
    }

    private void selectPeg(int x, int y){
        if(x < 0 || x > 6 || y < 0 || y > 6){
            return;
        }
        Peg p = pegs[x, y];

        if(p != null){
            c_Peg = p;
            firstPegPos = mousePos;
        }
    }

    private void upraisePeg(Peg p){
        RaycastHit hit;
        if(Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("myBoard"))){
            p.transform.position = p.transform.position + Vector3.up;
        }
    }

    void pegsPos(){
        RaycastHit hit;
        
        if(Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("myBoard"))){
            mousePos.y = (int) (hit.point.x-pegPosition.x);
            mousePos.x = (int) (hit.point.z-pegPosition.z);
        }
        else{
            mousePos.x = -100;
            mousePos.y = -100;
        }
    }

    private bool is_move_valid(int x1, int y1, int x2, int y2){
        int mid_X, mid_Y;
        if((x2 == 0 && y2 == 0) || (x2 == 0 && y2 == 1) || (x2 == 1 && y2 == 0) ||
        (x2 == 6 && y2 == 6) || (x2 == 6 && y2 == 5) || (x2 == 5 && y2 == 6) ||
        (x2 == 0 && y2 == 6) || (x2 == 0 && y2 == 5) || (x2 == 1 && y2 == 6) ||
        (x2 == 6 && y2 == 0) || (x2 == 6 && y2 == 1) || (x2 == 5 && y2 == 0)){
            return false;
        }
        if(x1 == x2){
            if(y1 > y2){
                if(y1 - y2 > 2 || y1 - y2 < 2){
                    return false;
                }
                mid_Y = y1 - 1;
            }
            else{
                if(y2 - y1 > 2 || y2 - y1 < 2){
                    return false;
                }
                mid_Y = y2 - 1;
            }
            if(pegs[x1, y1] != null && pegs[x2, y2] == null && pegs[x1, mid_Y] != null){
                return true;
            }
        }
        else if(y1 == y2){
            if(x1 > x2){
                if(x1 - x2 > 2 || x1 - x2 < 2){
                    return false;
                }
                mid_X = x1 - 1;
            }
            else{
                if(x2 - x1 > 2 || x2 - x1 < 2){
                    return false;
                }
                mid_X = x2 - 1;
            }
            if(pegs[x1, y1] != null && pegs[x2, y2] == null && pegs[mid_X, y1] != null){
                return true;
            }
        }
        return false;
    }

    bool is_game_over(){
        for(int x = 0; x < 7;x++)
        {
            for(int y = 0 ; y < 7 ; y++)
            {
                if(x > 1){
                    if (is_move_valid(x, y, x - 2, y))
                    {
                        return false;
                    }
                }
                if(x < 5){
                    if(is_move_valid(x, y, x+2, y))
                    {
                        return false;
                    }
                }
                if (y > 1){
                    if (is_move_valid(x, y, x, y - 2))
                    {
                        return false;
                    }
                }
                if (y < 5){
                    if (is_move_valid(x, y, x, y + 2))
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }
}